@extends('base')

@section('content')
    <h1>Schoenen overzicht!</h1>

        {{-- message --}}
        @if(session()->has('message')) 
            <p class="alert alert-info">
                {{ session('message') }}
            </p>
        @endif

    <ul class="list-group">
        @foreach($schoenen as $schoen)
            <li class="list-group-item"><a class="list-group-item list-group-item-action" href="/schoenen/{{$schoen->id}}">  {{ $schoen->merk}} &euro;{{ $schoen->prijs }} - {{ $schoen->categorie_naam }} </a></li>
        @endforeach
    </ul>
@endsection