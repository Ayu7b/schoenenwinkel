@extends('base')

@section('content')

<h1>Detailpagina</h1>
    <h2>Merk schoen: {{ $schoen->merk }}</h2>

    <p>Deze schoen kost {{ $schoen->prijs }}.</p>
    <p>De schoen maat is {{ $schoen->maat }}.</p>
    <p>De kleur van dit schoen is: </p>
    <div style="height: 100px; width: 100px; background-color: {{$schoen->kleur}}"></div>
    <p>Deze schoen valt onder de categorie : {{ $schoen->categorie_naam }}</p>

    <a class="btn btn-primary" href="/schoenen/{{$schoen->id}}/edit">Bewerk schoen</a>
    <form action="/schoenen/{{$schoen->id}}" method="POST">
        @csrf
        @method('DELETE')
        <input class="btn btn-danger" type="submit" value="Verwijder schoen">
    </form>

    <a class="btn btn-primary" href="/schoenen">Terug naar overzicht</a>

@endsection