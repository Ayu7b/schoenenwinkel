@extends('base')

@section('content')

<h1>Nieuwe Schoen Toevoegen</h1>
    <form action="/schoenen" method="post">
        @csrf
        <div class="form-group">
            <label class="form-label" for="">Merk</label>
            <input class="form-control" type="text" name="merk" id="merk">
        </div>  
 
        <div class="form-group">
            <label class="form-label" for="">Kleur</label>
            <input class="form-control" type="color" name="kleur" id="kleur">
        </div>
        
        <div class="form-group">
            <label class="form-label" for="">Maat</label>
            <input class="form-control" type="number" name="maat" id="maat">
        </div>

        <div class="form-group">
            <label class="form-label" for="">Prijs</label>
            <input class="form-control" type="number" steps="0.1" name="prijs" id="prijs">
        </div>

        <div class="form-group">
            <label class="form-label" for="">Categorie</label>
            <select class="form-select" name="categorie" id="categorie">
                <option value="">Selecteer categorie</option>
                @foreach($categorieen as $categorie)
                    <option value="{{ $categorie->id }}">{{ $categorie->naam }}</option>  
                @endforeach
            </select>
        </div>

        <input class="btn btn-primary" type="submit" value="Schoen toevoegen">

    </form>


@endsection