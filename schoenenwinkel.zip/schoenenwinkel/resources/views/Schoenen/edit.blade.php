@extends('base')

@section('content')

<h1>Bewerk schoen</h1>
<form action="/schoenen/{{$schoen->id}}" method="post">
    @csrf
    @method('PUT')
    
    <div class="form-group">
        <label for="">Merk</label>
        <input value="{{ $schoen->merk }}" type="text" name="merk" id="merk">
    </div>  
    <div class="form-group">
        <label for="">Kleur</label>
        <input value="{{ $schoen->kleur }}" type="color" name="kleur" id="kleur">
    </div>    

    <div class="form-group">
        <label for="">Maat</label>
        <input value="{{ $schoen->maat }}" type="number" name="maat" id="maat">
    </div>

    <div class="form-group">
        <label for="">Prijs</label>
        <input value="{{ $schoen->prijs }}" type="number" steps="0.1" name="prijs" id="prijs">
    </div>
    
    <div class="form-group">
        <label for="">Categorie</label>
        <select name="categorie" id="categorie">
            <option value="">Selecteer categorie</option>
            @foreach($categorieen as $categorie)
                <option @if($schoen->categorie_id == $categorie->id) selected @endif value="{{ $categorie->id }}">{{ $categorie->naam }}</option>  
            @endforeach
        </select>
    </div>

    <input type="submit" value="Schoen updaten">

</form>


@endsection