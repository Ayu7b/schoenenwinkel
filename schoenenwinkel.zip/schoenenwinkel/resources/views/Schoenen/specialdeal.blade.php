@extends('base')

@section('content')

<h1>Dit zijn schoenen boven de &euro;100 en boven de maat 38</h1>

<ul class="list-group">
    @foreach($schoenen as $schoen)
        <li class="list-group-item"><a class="list-group-item list-group-item-action" href="/schoenen/{{$schoen->id}}">  {{ $schoen->merk}} &euro;{{ $schoen->prijs }} - {{ $schoen->categorie_naam }} </a></li>
    @endforeach
</ul>

@endsection