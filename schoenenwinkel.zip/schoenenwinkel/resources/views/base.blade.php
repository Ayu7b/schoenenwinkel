<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css">
    <title>SchoenenWinkel</title>
</head>
<body>
    <div class="container">
        <header>
            <nav class="navbar" style="background-color: #e3f2fd;">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="/">Schoenen Overzicht</a>
                        <a class="nav-link" href="/schoenen/create">Schoen toevoegen</a>
                        <a class="nav-link" href="/specialdeal">Specialdeal</a>
                    </li>
                </ul>
            </nav>
        </header>
        <main>
            @yield('content')
        </main>
    </div>
</body>
</html>