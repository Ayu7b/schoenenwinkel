<?php

use App\Http\Controllers\SchoenenController;
use App\Http\Controllers\SpecialdealController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', [SchoenenController::class, 'index']);
Route::get('/schoenen', [SchoenenController::class, 'index']);

Route::get('/schoenen/create', [SchoenenController::class, 'create']);

Route::post('/schoenen', [SchoenenController::class, 'store']);

Route::get('/schoenen/{id}/edit', [SchoenenController::class, 'edit']);
Route::get('/schoenen/{id}', [SchoenenController::class, 'show']);
Route::put('/schoenen/{id}', [SchoenenController::class, 'update']);
Route::get('/schoenen/{id}', [SchoenenController::class, 'show']);

Route::delete('/schoenen/{id}', [SchoenenController::class, 'destroy']);

Route::get('/specialdeal', [SpecialdealController::class, 'index']);



