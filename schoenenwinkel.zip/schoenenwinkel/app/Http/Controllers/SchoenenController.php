<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class SchoenenController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $schoenen = DB::table('schoenen')
        ->join('categorieen', 'schoenen.categorie_id', '=', 'categorieen.id')
        ->select('schoenen.*', 'categorieen.naam as categorie_naam' )
        ->get();    

        // geef de data door aan de view
        return view('schoenen.index', [
            'schoenen' => $schoenen
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $categorieen = DB::table('categorieen')->get();

        // geef de data door aan de view
        return view('schoenen.create', [
            'categorieen' => $categorieen
        ]);

    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        DB::table('schoenen')->insert([
            'merk' => $request->merk,
            'kleur' => $request->kleur,
            'maat' => $request->maat,
            'prijs' => $request->prijs,
            'categorie_id' => $request->categorie
        ]);

        return redirect('/')->with('message', 'Schoen is toegevoegd!');

    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        $schoen = DB::table('schoenen')
        ->where('schoenen.id', $id)
        ->join('categorieen', 'schoenen.categorie_id', '=', 'categorieen.id')
        ->select('schoenen.*', 'categorieen.naam as categorie_naam' )
        ->get()
        ->first();
    
    return view('schoenen.show', [
        'schoen' => $schoen
    ]);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $schoen = DB::table('schoenen')
            ->where('id', $id)
            ->first();

        $categorieen = DB::table('categorieen')->get();


        return view('schoenen.edit', [
            'schoen' => $schoen,
            'categorieen' => $categorieen
        ]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $schoen =  DB::table('schoenen')
            ->where('id', $id)
            ->update([
            'merk' => $request->merk,
            'kleur' => $request->kleur,
            'maat' => $request->maat,
            'prijs' => $request->prijs,
            'categorie_id' => $request->categorie
        ]);

        return redirect('/')->with('message', 'Schoen is aangepast!');

    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
                
        $schoen = DB::table('schoenen')->where('id', $id)->delete();
        return redirect('/')->with('message', 'Schoen is verwijderd!');
    }
}
