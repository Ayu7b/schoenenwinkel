<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class SpecialdealController extends Controller
{
    public function index()
    {
        $schoenen = DB::table('schoenen')
        ->join('categorieen', 'schoenen.categorie_id', '=', 'categorieen.id')
        ->select('schoenen.*', 'categorieen.naam as categorie_naam' )
        ->where('schoenen.prijs', '>', '100')
        ->where('schoenen.maat', '>', '38')

        ->get();
        return view('schoenen.specialdeal',[
            'schoenen' => $schoenen
        ]);
    }
}
