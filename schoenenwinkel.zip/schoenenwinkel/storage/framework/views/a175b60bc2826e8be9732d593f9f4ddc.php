

<?php $__env->startSection('content'); ?>

<h1>Detailpagina</h1>
    <h2>Merk schoen: <?php echo e($schoen->merk); ?></h2>

    <p>Deze schoen kost <?php echo e($schoen->prijs); ?>.</p>
    <p>De schoen maat is <?php echo e($schoen->maat); ?>.</p>
    <p>De kleur van dit schoen is: </p>
    <div style="height: 100px; width: 100px; background-color: <?php echo e($schoen->kleur); ?>"></div>
    <p>Deze schoen valt onder de categorie : <?php echo e($schoen->categorie_naam); ?></p>

    <a class="btn btn-primary" href="/schoenen/<?php echo e($schoen->id); ?>/edit">Bewerk schoen</a>
    <form action="/schoenen/<?php echo e($schoen->id); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <input class="btn btn-danger" type="submit" value="Verwijder schoen">
    </form>

    <a class="btn btn-primary" href="/schoenen">Terug naar overzicht</a>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\schoenenwinkel\resources\views/schoenen/show.blade.php ENDPATH**/ ?>