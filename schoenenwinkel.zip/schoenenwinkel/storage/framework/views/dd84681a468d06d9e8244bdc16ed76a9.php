

<?php $__env->startSection('content'); ?>

<h1>Dit zijn schoenen boven de &euro;100 en boven de maat 38</h1>

<ul class="list-group">
    <?php $__currentLoopData = $schoenen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schoen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="list-group-item"><a class="list-group-item list-group-item-action" href="/schoenen/<?php echo e($schoen->id); ?>">  <?php echo e($schoen->merk); ?> &euro;<?php echo e($schoen->prijs); ?> - <?php echo e($schoen->categorie_naam); ?> </a></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\schoenenwinkel\resources\views/schoenen/specialdeal.blade.php ENDPATH**/ ?>