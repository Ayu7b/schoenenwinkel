

<?php $__env->startSection('content'); ?>

<h1>Bewerk schoen</h1>
<form action="/schoenen/<?php echo e($schoen->id); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    
    <div class="form-group">
        <label for="">Merk</label>
        <input value="<?php echo e($schoen->merk); ?>" type="text" name="merk" id="merk">
    </div>  
    <div class="form-group">
        <label for="">Kleur</label>
        <input value="<?php echo e($schoen->kleur); ?>" type="color" name="kleur" id="kleur">
    </div>    

    <div class="form-group">
        <label for="">Maat</label>
        <input value="<?php echo e($schoen->maat); ?>" type="number" name="maat" id="maat">
    </div>

    <div class="form-group">
        <label for="">Prijs</label>
        <input value="<?php echo e($schoen->prijs); ?>" type="number" steps="0.1" name="prijs" id="prijs">
    </div>
    
    <div class="form-group">
        <label for="">Categorie</label>
        <select name="categorie" id="categorie">
            <option value="">Selecteer categorie</option>
            <?php $__currentLoopData = $categorieen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option <?php if($schoen->categorie_id == $categorie->id): ?> selected <?php endif; ?> value="<?php echo e($categorie->id); ?>"><?php echo e($categorie->naam); ?></option>  
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <input type="submit" value="Schoen updaten">

</form>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\schoenenwinkel\resources\views/schoenen/edit.blade.php ENDPATH**/ ?>